// Copyright (C) 2003  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_XML_PARSEr_
#define DLIB_XML_PARSEr_

#include <string>

#include "xml_parser/xml_parser_kernel_interfaces.h"
#include "xml_parser/xml_parser_kernel_1.h"


#endif // DLIB_XML_PARSEr_

