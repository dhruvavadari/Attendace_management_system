// Copyright (C) 2006  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_MATH
#define DLIB_MATH

#include "math/bessel.h"
#include "math/windows.h"

#endif //DLIB_MATH
