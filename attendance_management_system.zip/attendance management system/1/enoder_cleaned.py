
import cv2
import os
import face_recognition
import pickle

# Path to student images
folder_path = "Images"
image_files = os.listdir(folder_path)

student_images = []
student_ids = []

# Load images and extract IDs
for filename in image_files:
    image_path = os.path.join(folder_path, filename)
    image = cv2.imread(image_path)
    if image is not None:
        student_images.append(image)
        student_ids.append(os.path.splitext(filename)[0])
    else:
        print(f"Warning: Could not read {filename}")

# Encode faces
def find_encodings(images):
    encode_list = []
    for img in images:
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encodings = face_recognition.face_encodings(rgb_img)
        if encodings:
            encode_list.append(encodings[0])
        else:
            print("Warning: No face found in one of the images")
    return encode_list

print("Encoding started...")
encoded_list = find_encodings(student_images)
print(f"Encoding complete. {len(encoded_list)} faces encoded.")

# Save encodings and IDs
data = [encoded_list, student_ids]
with open('Encode_file.p', 'wb') as file:
    pickle.dump(data, file)

print("Encodings saved to Encode_file.p")
