import cv2
import os
import pickle
import face_recognition
import numpy as np
video_cap=cv2.VideoCapture(0)
video_cap.set(3,640)
video_cap.set(4,480)

backgroung_img=cv2.imread("Resources/background.png")
modes_path="Resources/Modes"
modes_list=os.listdir(modes_path)
img_modes=[]
for path in modes_list:
    img_modes.append(cv2.imread(os.path.join(modes_path,path)))
file=open('Encode_file.p','rb')
encodinglist_withId=pickle.load(file)
file.close()
enocodelistknown,stu_ids=encodinglist_withId




while True:
    ret,video_data=video_cap.read()

    imgs=cv2.resize(video_data,(0,0),None,0.25,0.25)
    imgs=cv2.cvtColor(imgs,cv2.COLOR_BGR2RGB)
    facecurframe=face_recognition.face_locations(imgs)
    encodecurframe=face_recognition.face_encodings(imgs,facecurframe)
    backgroung_img[162:162+480,55:55+640]=video_data
    backgroung_img[44:44+633,808:808+414]=img_modes[0]
    for encodeface,faceloc in zip(encodecurframe,facecurframe):
        matches=face_recognition.compare_faces(enocodelistknown,encodeface)
        facedis=face_recognition.face_distance(enocodelistknown,encodeface)
        print("matches",matches)
        print("facedis",facedis)
    
    #cv2.imshow("recording",video_data)
    cv2.imshow("background",backgroung_img)
    if cv2.waitKey(10)== ord("a"):
        break
cv2.destroyAllWindows() 