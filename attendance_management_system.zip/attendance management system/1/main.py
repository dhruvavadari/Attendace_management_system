
import cv2
import os
import pickle
import face_recognition
import numpy as np

# Initialize webcam
video_cap = cv2.VideoCapture(0)
video_cap.set(3, 640)
video_cap.set(4, 480)

# Load background image
background_img = cv2.imread("Resources/background.png")

# Load UI mode images
modes_path = "Resources/Modes"
modes_list = os.listdir(modes_path)
img_modes = [cv2.imread(os.path.join(modes_path, path)) for path in modes_list]

# Load known face encodings
try:
    with open('Encode_file.p', 'rb') as file:
        encodinglist_with_id = pickle.load(file)
    encode_list_known, stu_ids = encodinglist_with_id
except Exception as e:
    print("Error loading encodings:", e)
    exit()

# Main loop
while True:
    ret, video_data = video_cap.read()
    if not ret:
        print("Failed to grab frame")
        break

    # Resize and convert frame for face recognition
    small_frame = cv2.resize(video_data, (0, 0), None, 0.25, 0.25)
    rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

    face_locations = face_recognition.face_locations(rgb_small_frame)
    face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

    # Draw video feed and UI on background
    background_img[162:162+480, 55:55+640] = video_data
    background_img[44:44+633, 808:808+414] = img_modes[0]

    for encode_face, face_loc in zip(face_encodings, face_locations):
        matches = face_recognition.compare_faces(encode_list_known, encode_face)
        face_distances = face_recognition.face_distance(encode_list_known, encode_face)
        match_index = np.argmin(face_distances)

        if matches[match_index]:
            student_id = stu_ids[match_index]
            print(f"Recognized ID: {student_id}")

    # Display final output
    cv2.imshow("Attendance System", background_img)

    # Break loop on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Cleanup
video_cap.release()
cv2.destroyAllWindows()
