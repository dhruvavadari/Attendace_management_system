import cv2
import os
import face_recognition
import pickle

folder_path="Images"
stupath_list=os.listdir(folder_path)
stu_list=[]
stu_id=[]
for path in stupath_list:
    stu_list.append(cv2.imread(os.path.join(folder_path,path)))
    #print(os.path.splitext(path[0]))
    stu_id.append(os.path.splitext(path)[0])


def findencodings(studentlist):
    encodelist=[]
    for img in studentlist:
        img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        encode=face_recognition.face_encodings(img)[0]
        encodelist.append(encode)
    return encodelist
print("encoding started")
encodelistknown=findencodings(stu_list)
print(len(encodelistknown))
encodinglist_withId=[encodelistknown,stu_id]
print("encoding complete")
file=open('Encode_file.p','wb')
pickle.dump(encodinglist_withId,file)
file.close()



    
